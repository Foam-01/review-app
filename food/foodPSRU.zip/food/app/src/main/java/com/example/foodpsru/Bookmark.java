package com.example.foodpsru;

public class Bookmark {
}
